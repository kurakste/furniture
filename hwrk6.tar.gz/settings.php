<?php 
return [
    'db' => [
    'host'=>'127.0.0.1', 
    'user'=>'homework',
    'password'=>'akfyem',
    'dbname'=>'furniture'
    ],
    'loger'=>[
        'loger'=>true, // Логер включен. 
        'logfile'=>'var/log/app.log'
    ]

];
