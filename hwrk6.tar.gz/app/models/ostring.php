<?php

namespace App\Models;

use App\Models\Model;

class Ostring extends Model 
{
    public $oid;
    public $name;
    public $price;
    public $amount;

}

