<?php

namespace App\Models;

use App\Models\Model;

Class Category extends Model 
{
    public $name;
}
