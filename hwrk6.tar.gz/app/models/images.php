<?php

namespace App\Models;

use App\Models\Model;

Class Images extends Model 
{
    public $filename;
    public $iid;
}
