<?php 

namespace App\Controllers;

use App\Models\User;
use App\Models\Link;

class Controller
{
    public function secure() 
    {
        $this->validSessionId();
    }

    // Проверяет установлена ли у текущего пользователя валидное сочитание 
    // ID пользователя и ID  сессии. Если нет, делает редирект на станицу 
    // входа пользователя. 
    public function validSessionId()
    {
        $id = $_COOKIE['userId'] ?? null;
        if ($id) {
            $session = $_COOKIE['sessionId'] ?? '';
            $user = new User;
            $res = $user->getOneById($id);
            if (!$res) {
                header('Location: /login');
                die;
            }
        } else {
            header('Location: /login');
        }

        if (!($session == $user->sessionId)) {
            header('Location: /login');
            die;
        }
    }
    
    // Подставляет переменные и рендерит шаблон.
    public function getPage($template, $data)
    {

        $loader = new \Twig_Loader_Filesystem(
            __DIR__.'/../../view'
        );

        $twig = new \Twig_Environment(
            $loader, 
            array('cache' => false,)
        );

        $out = $twig->render($template, $data);
        return $out;
    }

    // Проверяет пришли ли с пост запросом необходимые имена переменных. 
    // Если пришли, можно делать extract и пользоваться ими. 
    protected function chekRequiredFields(array $input)
    {   
        $out=[];
        foreach ($input as $field){
            if (!isset($_POST[$field]) || $_POST[$field] == '') {
                $out[]['emessage'] = "Заполните пожалуйста поле {$field}.";
            }

        }
        return $out;
    }

    // Просто хелпер редиректор + die
    public function redirect(string $path)
    {
        header("Location: $path");
        die;
    }

    public function saveHistoryForUser() 
    {
        $id = $_COOKIE['userId'] ?? ''; 
        $lk = new Link;
        $lk->link = $_SERVER['REQUEST_URI'];
        $lk->uid = $id;
        $lk->save();
    }
}
